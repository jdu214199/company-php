<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
 
    <title>Main page</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include "layouts/header.php"?>
    <main>
        <h1>Service page</h1>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident distinctio, cumque voluptate perspiciatis obcaecati voluptas quos. Nisi aut, culpa nulla modi deleniti laudantium sit nam temporibus pariatur officiis voluptate ipsa.
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident distinctio, cumque voluptate perspiciatis obcaecati voluptas quos. Nisi aut, culpa nulla modi deleniti laudantium sit nam temporibus pariatur officiis voluptate ipsa.
       <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident distinctio, cumque voluptate perspiciatis obcaecati voluptas quos. Nisi aut, culpa nulla modi deleniti laudantium sit nam temporibus pariatur officiis voluptate ipsa.
</main>
<?php include "layouts/footer.php"?>
 </body>
</html>