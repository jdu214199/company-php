<header>
    <ul>
<li><a href="index.php">Apple</li>
<li><a href="about.php">about</li>
<li><a href="contacs.php">contacs</li>
<li><a href="news.php">news</li>
<li><a href="service.php">service</a</li>
    </ul>
</header>


