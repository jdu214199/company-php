<footer>
    <p>Phone number: +998(94) 233-33-33</p>
    <p>Apple&copy; .inc</p>
</fofter>
